﻿namespace Infrastructure
{
    public class Filter
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public string Contrast { get; set; }
    }
}