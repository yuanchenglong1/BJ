namespace OpenAuth.App.SSO
{
    public class LoginResult
    {
        public bool Success;
        public string ErrorMsg;
        public string ReturnUrl;
        public string Token;
    }
}